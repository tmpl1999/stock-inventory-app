import { useState } from 'react';
import { CustomerWithStats } from '@/hooks/use-customers';
import { Order } from '@/hooks/use-customer-orders';
import { format } from 'date-fns';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  User, 
  Mail, 
  Phone, 
  Home, 
  Package, 
  DollarSign, 
  Calendar,
  Search
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import OrderDetailsDialog from '@/components/orders/OrderDetailsDialog';

interface CustomerDetailsProps {
  customer: CustomerWithStats;
  customerOrders: Order[];
  onBack: () => void;
}

const OrderStatusBadge = ({ status }: { status: string }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  
  switch (status.toLowerCase()) {
    case 'completed':
      variant = "default"; // Green
      break;
    case 'processing':
      variant = "secondary"; // Orange/Yellow
      break;
    case 'cancelled':
      variant = "destructive"; // Red
      break;
    case 'pending':
    default:
      variant = "outline"; // Gray outline
      break;
  }
  
  return <Badge variant={variant}>{status}</Badge>;
};

const CustomerDetails: React.FC<CustomerDetailsProps> = ({ customer, customerOrders, onBack }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  
  // Calculate statistics
  const completedOrders = customerOrders.filter(order => order.status === 'completed').length;
  const cancelledOrders = customerOrders.filter(order => order.status === 'cancelled').length;
  const pendingOrders = customerOrders.filter(order => order.status === 'pending' || order.status === 'processing').length;
  
  // Filter orders based on search and status
  const filteredOrders = customerOrders.filter(order => {
    const matchesSearch = 
      searchQuery === '' ||
      order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.items.some(item => item.productName.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  // Find selected order
  const selectedOrder = customerOrders.find(order => order.id === selectedOrderId);
  
  // Product purchase history (unique products with quantities)
  const productHistory = customerOrders.flatMap(order => 
    order.items.map(item => ({
      productId: item.productId,
      productName: item.productName,
      date: order.orderDate,
      quantity: item.quantity,
      status: order.status,
      unitPrice: item.unitPrice,
      orderId: order.id,
      orderNumber: order.orderNumber
    }))
  );
  
  // Group by product and calculate total quantity purchased
  const productSummary = productHistory.reduce((acc, item) => {
    if (!acc[item.productId]) {
      acc[item.productId] = {
        productId: item.productId,
        productName: item.productName,
        totalQuantity: 0,
        latestPurchase: new Date(0),
        purchases: []
      };
    }
    
    acc[item.productId].totalQuantity += item.quantity;
    const purchaseDate = new Date(item.date);
    if (purchaseDate > acc[item.productId].latestPurchase) {
      acc[item.productId].latestPurchase = purchaseDate;
    }
    
    acc[item.productId].purchases.push({
      date: item.date,
      quantity: item.quantity,
      status: item.status,
      unitPrice: item.unitPrice,
      orderId: item.orderId,
      orderNumber: item.orderNumber
    });
    
    return acc;
  }, {} as Record<string, {
    productId: string;
    productName: string;
    totalQuantity: number;
    latestPurchase: Date;
    purchases: Array<{
      date: string;
      quantity: number;
      status: string;
      unitPrice: number;
      orderId: string;
      orderNumber: string;
    }>;
  }>);
  
  const productSummaryArray = Object.values(productSummary).sort((a, b) => 
    b.latestPurchase.getTime() - a.latestPurchase.getTime()
  );
  
  const filteredProducts = productSummaryArray.filter(product =>
    searchQuery === '' || product.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={onBack}>
          Back to Customer List
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{customer.name}</CardTitle>
          <CardDescription>Customer profile and purchase history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h3 className="text-lg font-medium mb-3">Contact Information</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span>{customer.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span>{customer.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span>{customer.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Home className="h-4 w-4 text-gray-500" />
                  <span>{customer.address}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-3">Order Statistics</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-gray-500 mb-1">
                    <Package className="h-4 w-4" />
                    <span className="text-sm">Total Orders</span>
                  </div>
                  <div className="text-2xl font-bold">{customer.totalOrders}</div>
                  <div className="mt-1 text-xs text-gray-500">
                    <span className="text-green-600">{completedOrders} completed</span> • 
                    <span className="text-yellow-600 ml-1">{pendingOrders} pending</span> •
                    <span className="text-red-600 ml-1">{cancelledOrders} cancelled</span>
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-gray-500 mb-1">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-sm">Total Spent</span>
                  </div>
                  <div className="text-2xl font-bold">
                    {formatCurrency(customer.totalSpent)}
                  </div>
                  <div className="mt-1 text-xs text-gray-500">
                    Avg. {formatCurrency(customer.totalOrders ? customer.totalSpent / customer.totalOrders : 0)} per order
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-gray-500 mb-1">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm">Last Order</span>
                  </div>
                  <div className="text-lg font-medium">
                    {customer.lastOrderDate 
                      ? format(new Date(customer.lastOrderDate), 'MMM dd, yyyy')
                      : 'N/A'
                    }
                  </div>
                  <div className="mt-1">
                    {customer.lastOrderStatus && (
                      <OrderStatusBadge status={customer.lastOrderStatus} />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2">
              <TabsTrigger value="overview">Orders History</TabsTrigger>
              <TabsTrigger value="products">Products Purchased</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                  <Input 
                    type="search" 
                    placeholder="Search orders..." 
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {filteredOrders.length === 0 ? (
                <div className="flex justify-center items-center h-32 border rounded-md">
                  <p className="text-gray-500">No orders found</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order #</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">#{order.orderNumber}</TableCell>
                        <TableCell>
                          {format(new Date(order.orderDate), 'MMM dd, yyyy')}
                        </TableCell>
                        <TableCell>{order.items.length}</TableCell>
                        <TableCell>{formatCurrency(order.totalAmount)}</TableCell>
                        <TableCell>
                          <OrderStatusBadge status={order.status} />
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setSelectedOrderId(order.id)}
                          >
                            Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
            
            <TabsContent value="products" className="space-y-4 mt-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Input 
                  type="search" 
                  placeholder="Search products..." 
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {filteredProducts.length === 0 ? (
                <div className="flex justify-center items-center h-32 border rounded-md">
                  <p className="text-gray-500">No products found</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40%]">Product</TableHead>
                      <TableHead>Total Qty</TableHead>
                      <TableHead>Latest Purchase</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map((product) => (
                      <TableRow key={product.productId}>
                        <TableCell className="font-medium">{product.productName}</TableCell>
                        <TableCell>{product.totalQuantity}</TableCell>
                        <TableCell>
                          {format(product.latestPurchase, 'MMM dd, yyyy')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {selectedOrder && (
        <OrderDetailsDialog 
          order={selectedOrder} 
          isOpen={!!selectedOrderId} 
          onClose={() => setSelectedOrderId(null)} 
        />
      )}
    </div>
  );
};

export default CustomerDetails;