import { useState } from 'react';
import { Search, ArrowUpDown, User, Calendar, DollarSign, Package } from 'lucide-react';
import { CustomerWithStats } from '@/hooks/use-customers';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';

interface CustomerListProps {
  customers: CustomerWithStats[];
  isLoading: boolean;
  error: string | null;
  onCustomerSelect: (customerId: string) => void;
  onSort: (column: string) => void;
  sortColumn: string;
  sortDirection: 'asc' | 'desc';
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const getStatusBadgeVariant = (status: string | null) => {
  if (!status) return "outline";
  
  switch (status.toLowerCase()) {
    case 'completed':
      return "default"; // Green
    case 'processing':
      return "secondary"; // Orange/Yellow
    case 'cancelled':
      return "destructive"; // Red
    case 'pending':
    default:
      return "outline"; // Gray outline
  }
};

const CustomerList: React.FC<CustomerListProps> = ({
  customers,
  isLoading,
  error,
  onCustomerSelect,
  onSort,
  sortColumn,
  sortDirection,
  searchQuery,
  setSearchQuery
}) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
          <Input
            type="search"
            placeholder="Search customers..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline">Export</Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 dark:text-gray-400">Loading customers...</p>
        </div>
      ) : error ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-red-500 dark:text-red-400">Error loading customers: {error}</p>
        </div>
      ) : customers.length === 0 ? (
        <div className="flex justify-center items-center h-64 flex-col space-y-2">
          <p className="text-gray-500 dark:text-gray-400">No customers found</p>
          <p className="text-sm text-gray-400 dark:text-gray-500">
            Try adjusting your search criteria
          </p>
        </div>
      ) : (
        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[250px]">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="font-medium" 
                    onClick={() => onSort('name')}
                  >
                    <User className="mr-2 h-4 w-4" />
                    Customer
                    {sortColumn === 'name' && (
                      <ArrowUpDown className="ml-2 h-4 w-4" />
                    )}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="font-medium" 
                    onClick={() => onSort('totalOrders')}
                  >
                    <Package className="mr-2 h-4 w-4" />
                    Orders
                    {sortColumn === 'totalOrders' && (
                      <ArrowUpDown className="ml-2 h-4 w-4" />
                    )}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="font-medium" 
                    onClick={() => onSort('totalSpent')}
                  >
                    <DollarSign className="mr-2 h-4 w-4" />
                    Total Spent
                    {sortColumn === 'totalSpent' && (
                      <ArrowUpDown className="ml-2 h-4 w-4" />
                    )}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="font-medium" 
                    onClick={() => onSort('lastOrderDate')}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    Last Order
                    {sortColumn === 'lastOrderDate' && (
                      <ArrowUpDown className="ml-2 h-4 w-4" />
                    )}
                  </Button>
                </TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.map((customer) => (
                <TableRow 
                  key={customer.id} 
                  className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50"
                  onClick={() => onCustomerSelect(customer.id)}
                >
                  <TableCell>
                    <div>
                      <div className="font-medium">{customer.name}</div>
                      <div className="text-xs text-gray-500">{customer.email}</div>
                    </div>
                  </TableCell>
                  <TableCell>{customer.totalOrders}</TableCell>
                  <TableCell>{formatCurrency(customer.totalSpent)}</TableCell>
                  <TableCell>
                    {customer.lastOrderDate ? (
                      format(new Date(customer.lastOrderDate), 'MMM dd, yyyy')
                    ) : (
                      'N/A'
                    )}
                  </TableCell>
                  <TableCell>
                    {customer.lastOrderStatus ? (
                      <Badge variant={getStatusBadgeVariant(customer.lastOrderStatus) as "default" | "secondary" | "destructive" | "outline"}>
                        {customer.lastOrderStatus}
                      </Badge>
                    ) : (
                      'N/A'
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default CustomerList;