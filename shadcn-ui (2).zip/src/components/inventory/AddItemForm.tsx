import { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Category, Supplier } from '@/types';

const formSchema = z.object({
  name: z.string().min(2, {
    message: 'Name must be at least 2 characters.',
  }),
  sku: z.string().min(2, {
    message: 'SKU must be at least 2 characters.',
  }),
  description: z.string().optional(),
  category_id: z.string({
    required_error: "Please select a category.",
  }),
  quantity: z.coerce.number().min(0, {
    message: 'Quantity must be 0 or greater.',
  }),
  cost_price: z.coerce.number().min(0, {
    message: 'Cost price must be 0 or greater.',
  }),
  selling_price: z.coerce.number().min(0, {
    message: 'Selling price must be 0 or greater.',
  }),
  reorder_level: z.coerce.number().min(0, {
    message: 'Reorder level must be 0 or greater.',
  }),
  supplier_id: z.string().optional(),
  location: z.string().optional(),
});

interface AddItemFormProps {
  onSubmit: (values: z.infer<typeof formSchema>) => void;
  categories: Category[];
  suppliers: Supplier[];
  isLoading?: boolean;
}

export default function AddItemForm({ 
  onSubmit, 
  categories, 
  suppliers, 
  isLoading = false 
}: AddItemFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      sku: '',
      description: '',
      category_id: '',
      quantity: 0,
      cost_price: 0,
      selling_price: 0,
      reorder_level: 5,
      supplier_id: '',
      location: '',
    },
  });

  const [isAutoGeneratingSKU, setIsAutoGeneratingSKU] = useState(true);
  
  // Auto-generate SKU when name changes and autoGenerate is true
  const watchName = form.watch('name');
  
  // Generate SKU based on name and current timestamp
  const generateSKU = (name: string) => {
    if (!name) return '';
    const prefix = name.slice(0, 3).toUpperCase();
    const timestamp = new Date().getTime().toString().slice(-6);
    return `${prefix}${timestamp}`;
  };
  
  // Update SKU when name changes if auto-generate is enabled
  useState(() => {
    if (isAutoGeneratingSKU && watchName) {
      form.setValue('sku', generateSKU(watchName));
    }
  });

  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    onSubmit(values);
    form.reset();
  };

  return (
    <div className="p-4 bg-white rounded-lg border">
      <h2 className="text-xl font-bold mb-4">Add New Inventory Item</h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name *</FormLabel>
                  <FormControl>
                    <Input placeholder="Product name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormField
                control={form.control}
                name="sku"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex justify-between">
                      <span>SKU *</span>
                      <div className="flex items-center">
                        <input 
                          type="checkbox" 
                          checked={isAutoGeneratingSKU}
                          onChange={() => setIsAutoGeneratingSKU(!isAutoGeneratingSKU)}
                          id="autoGenSku" 
                          className="mr-2 h-4 w-4"
                        />
                        <label htmlFor="autoGenSku" className="text-xs text-gray-500">Auto-generate</label>
                      </div>
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Stock keeping unit" 
                        {...field} 
                        readOnly={isAutoGeneratingSKU} 
                        className={isAutoGeneratingSKU ? "bg-gray-50" : ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Product description" 
                    className="resize-y"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="category_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category *</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supplier_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supplier</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a supplier" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {suppliers.map(supplier => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity *</FormLabel>
                  <FormControl>
                    <Input type="number" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="cost_price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cost Price ($) *</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="selling_price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Selling Price ($) *</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="reorder_level"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reorder Level *</FormLabel>
                  <FormControl>
                    <Input type="number" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Storage Location</FormLabel>
                  <FormControl>
                    <Input placeholder="Warehouse A, Shelf B3, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => form.reset()}>
              Reset
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Adding...' : 'Add Item'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}