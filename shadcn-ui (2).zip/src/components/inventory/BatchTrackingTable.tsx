import React from 'react';
import { format } from 'date-fns';
import { MoveVertical, Calendar, PackageCheck, Info, Move, Edit } from 'lucide-react';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface BatchItem {
  id: string;
  productId: string;
  productName: string;
  batchNumber: string;
  quantity: number;
  warehouse: string;
  location: string;
  receivedDate: string;
  expiryDate?: string;
  status: 'Available' | 'Low Stock' | 'Out of Stock' | 'Reserved';
}

interface BatchTrackingTableProps {
  batches: BatchItem[];
  onViewDetails: (batchId: string) => void;
  onUpdateBatch: (batchId: string) => void;
  onMoveBatch: (batchId: string) => void;
}

const BatchTrackingTable = ({
  batches,
  onViewDetails,
  onUpdateBatch,
  onMoveBatch,
}: BatchTrackingTableProps) => {
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'Available':
        return 'default';
      case 'Low Stock':
        return 'secondary';
      case 'Out of Stock':
        return 'destructive';
      case 'Reserved':
        return 'outline';
      default:
        return 'outline';
    }
  };

  return (
    <div className="overflow-auto">
      {batches.length === 0 ? (
        <div className="py-12 text-center">
          <PackageCheck className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600" />
          <p className="mt-4 text-lg font-medium text-gray-500 dark:text-gray-400">No batch data available</p>
          <p className="text-sm text-gray-400 dark:text-gray-500">
            Batch tracking data will appear here once items are received into inventory
          </p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Batch Number</TableHead>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Quantity</TableHead>
              <TableHead>Warehouse</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>
                <div className="flex items-center">
                  Received Date
                  <MoveVertical className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead>Expiry Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {batches.map((batch) => (
              <TableRow key={batch.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <TableCell className="font-medium">{batch.batchNumber}</TableCell>
                <TableCell>{batch.productName}</TableCell>
                <TableCell className="text-right">{batch.quantity}</TableCell>
                <TableCell>{batch.warehouse}</TableCell>
                <TableCell>
                  <span className="text-sm text-muted-foreground">{batch.location}</span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                    <span>{format(new Date(batch.receivedDate), 'MMM dd, yyyy')}</span>
                  </div>
                </TableCell>
                <TableCell>
                  {batch.expiryDate ? (
                    <span className="text-sm text-muted-foreground">
                      {format(new Date(batch.expiryDate), 'MMM dd, yyyy')}
                    </span>
                  ) : (
                    <span className="text-sm text-muted-foreground">N/A</span>
                  )}
                </TableCell>
                <TableCell>
                  <Badge variant={getStatusBadgeVariant(batch.status) as "default" | "secondary" | "destructive" | "outline"}>{batch.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              onViewDetails(batch.id);
                            }}
                          >
                            <Info className="h-4 w-4" />
                            <span className="sr-only">View Details</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>View Details</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateBatch(batch.id);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Edit Batch</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              onMoveBatch(batch.id);
                            }}
                          >
                            <Move className="h-4 w-4" />
                            <span className="sr-only">Move</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Move Batch</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
};

export default BatchTrackingTable;