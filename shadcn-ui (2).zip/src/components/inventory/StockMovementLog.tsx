import React from 'react';
import { ArrowDownUp, MoveVertical, ArrowRight, Calendar, Package, Warehouse, Info, Filter, Search } from 'lucide-react';
import { format } from 'date-fns';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  batchNumber: string;
  quantity: number;
  fromWarehouse: string;
  fromLocation: string;
  toWarehouse: string;
  toLocation: string;
  movementType: 'New Stock' | 'Transfer' | 'Stock Out' | 'Adjustment';
  movementReason?: string;
  date: string;
  initiatedBy: string;
}

interface StockMovementLogProps {
  movements: StockMovement[];
  onViewDetails: (movementId: string) => void;
}

const StockMovementLog = ({ movements, onViewDetails }: StockMovementLogProps) => {
  const getMovementBadgeVariant = (type: string) => {
    switch (type) {
      case 'New Stock':
        return 'default'; // Green
      case 'Transfer':
        return 'secondary'; // Purple
      case 'Stock Out':
        return 'destructive'; // Red
      case 'Adjustment':
        return 'outline'; // Outline
      default:
        return 'outline';
    }
  };

  const getMovementIcon = (type: string) => {
    switch (type) {
      case 'New Stock':
        return <Package className="h-4 w-4" />;
      case 'Transfer':
        return <ArrowRight className="h-4 w-4" />;
      case 'Stock Out':
        return <ArrowDownUp className="h-4 w-4" />;
      case 'Adjustment':
        return <Filter className="h-4 w-4" />;
      default:
        return <MoveVertical className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
          <Input type="text" placeholder="Search movements..." className="pl-8" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            Export
          </Button>
        </div>
      </div>

      <div className="overflow-auto">
        {movements.length === 0 ? (
          <div className="py-12 text-center">
            <MoveVertical className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600" />
            <p className="mt-4 text-lg font-medium text-gray-500 dark:text-gray-400">
              No stock movements recorded
            </p>
            <p className="text-sm text-gray-400 dark:text-gray-500">
              Stock movement history will appear here once items are moved between locations
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Batch #</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>From</TableHead>
                <TableHead>To</TableHead>
                <TableHead>By</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {movements.map((movement) => (
                <TableRow key={movement.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <TableCell>
                    <div className="flex items-center">
                      <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                      <span>{format(new Date(movement.date), 'MMM dd, yyyy')}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{movement.productName}</TableCell>
                  <TableCell>{movement.batchNumber}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {getMovementIcon(movement.movementType)}
                      <Badge variant={getMovementBadgeVariant(movement.movementType) as "default" | "secondary" | "destructive" | "outline"}>
                        {movement.movementType}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{movement.quantity}</TableCell>
                  <TableCell>
                    {movement.fromWarehouse ? (
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{movement.fromWarehouse}</span>
                        <span className="text-xs text-muted-foreground">{movement.fromLocation}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {movement.toWarehouse ? (
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{movement.toWarehouse}</span>
                        <span className="text-xs text-muted-foreground">{movement.toLocation}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>{movement.initiatedBy}</TableCell>
                  <TableCell className="text-right">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              onViewDetails(movement.id);
                            }}
                          >
                            <Info className="h-4 w-4" />
                            <span className="sr-only">View Details</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>View Details</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
};

export default StockMovementLog;