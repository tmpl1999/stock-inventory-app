import React, { useState } from 'react';
import { format } from 'date-fns';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { StockMovement } from '@/hooks/use-stock-movements';
import { ArrowRight, ArrowDownUp, Filter, Package, Calendar, Search, Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { LineChart } from '@/components/ui/chart';

interface ProductMovementHistoryProps {
  productId: string;
  productName: string;
  movements: StockMovement[];
  onViewDetails: (movementId: string) => void;
}

const ProductMovementHistory: React.FC<ProductMovementHistoryProps> = ({
  productId,
  productName,
  movements,
  onViewDetails
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  
  // Filter movements based on search term, date, and type
  const filteredMovements = movements.filter(movement => {
    const matchesSearch = 
      searchTerm === '' ||
      movement.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.movementReason?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.initiatedBy.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = typeFilter === 'all' || movement.movementType === typeFilter;
    
    let matchesDate = true;
    if (dateFilter !== 'all') {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const movementDate = new Date(movement.date);
      
      // Date variables needed for filtering
      const thisWeekStart = new Date(today);
      thisWeekStart.setDate(today.getDate() - today.getDay());
      
      const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
      
      const threeMonthsAgo = new Date(today);
      threeMonthsAgo.setMonth(today.getMonth() - 3);
      
      switch (dateFilter) {
        case 'today':
          matchesDate = movementDate >= today;
          break;
        case 'thisWeek':
          matchesDate = movementDate >= thisWeekStart;
          break;
        case 'thisMonth':
          matchesDate = movementDate >= thisMonthStart;
          break;
        case 'last3Months':
          matchesDate = movementDate >= threeMonthsAgo;
          break;
      }
    }
    
    return matchesSearch && matchesType && matchesDate;
  });
  
  // Sort movements by date (newest first)
  const sortedMovements = [...filteredMovements].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  // Calculate inventory level over time for charting
  const chartData = React.useMemo(() => {
    // Group movements by date (day) and calculate cumulative inventory
    const sortedByDate = [...movements].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    let currentLevel = 0;
    const dataPoints: {date: string; level: number}[] = [];
    
    sortedByDate.forEach(movement => {
      const dateStr = format(new Date(movement.date), 'MMM dd');
      
      if (movement.movementType === 'New Stock') {
        currentLevel += movement.quantity;
      } else if (movement.movementType === 'Stock Out') {
        currentLevel -= movement.quantity;
      }
      
      dataPoints.push({
        date: dateStr,
        level: currentLevel
      });
    });
    
    return {
      labels: dataPoints.map(d => d.date),
      datasets: [
        {
          label: 'Inventory Level',
          data: dataPoints.map(d => d.level),
          backgroundColor: 'rgba(59, 130, 246, 0.5)',
          borderColor: 'rgba(59, 130, 246, 1)',
        }
      ]
    };
  }, [movements]);
  
  const getMovementTypeIcon = (type: string) => {
    switch (type) {
      case 'New Stock':
        return <Package className="h-4 w-4" />;
      case 'Transfer':
        return <ArrowRight className="h-4 w-4" />;
      case 'Stock Out':
        return <ArrowDownUp className="h-4 w-4" />;
      case 'Adjustment':
        return <Filter className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getMovementBadgeStyle = (type: string) => {
    switch (type) {
      case 'New Stock':
        return 'default';
      case 'Transfer':
        return 'secondary';
      case 'Stock Out':
        return 'destructive';
      case 'Adjustment':
        return 'outline';
      default:
        return 'outline';
    }
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Product Movement History</CardTitle>
          <CardDescription>
            Inventory movement history for {productName}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Chart */}
            <div className="h-64">
              <LineChart data={chartData} />
            </div>
            
            {/* Filters */}
            <div className="flex flex-col sm:flex-row justify-between gap-4 pt-4">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Input 
                  type="search" 
                  placeholder="Search movements..." 
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex gap-2">
                <div className="min-w-[130px]">
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="New Stock">New Stock</SelectItem>
                      <SelectItem value="Stock Out">Stock Out</SelectItem>
                      <SelectItem value="Transfer">Transfer</SelectItem>
                      <SelectItem value="Adjustment">Adjustment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="min-w-[130px]">
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Date range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Time</SelectItem>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="thisWeek">This Week</SelectItem>
                      <SelectItem value="thisMonth">This Month</SelectItem>
                      <SelectItem value="last3Months">Last 3 Months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            {/* Table */}
            <div className="overflow-auto">
              {sortedMovements.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No movement records found for this product
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Batch #</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>By</TableHead>
                      <TableHead className="text-right">Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedMovements.map((movement) => (
                      <TableRow key={movement.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                            <span>{format(new Date(movement.date), 'MMM dd, yyyy')}</span>
                          </div>
                        </TableCell>
                        <TableCell>{movement.batchNumber}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            {getMovementTypeIcon(movement.movementType)}
                            <Badge variant={getMovementBadgeStyle(movement.movementType) as "default" | "secondary" | "destructive" | "outline"}>
                              {movement.movementType}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{movement.quantity}</TableCell>
                        <TableCell>
                          {movement.fromWarehouse ? (
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{movement.fromWarehouse}</span>
                              <span className="text-xs text-muted-foreground">{movement.fromLocation}</span>
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {movement.toWarehouse ? (
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{movement.toWarehouse}</span>
                              <span className="text-xs text-muted-foreground">{movement.toLocation}</span>
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <span className="text-sm">{movement.movementReason || '-'}</span>
                          {movement.orderNumber && (
                            <div className="text-xs text-blue-600">Order #{movement.orderNumber}</div>
                          )}
                        </TableCell>
                        <TableCell>{movement.initiatedBy}</TableCell>
                        <TableCell className="text-right">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => onViewDetails(movement.id)}
                                >
                                  <Info className="h-4 w-4" />
                                  <span className="sr-only">View Details</span>
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Details</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProductMovementHistory;