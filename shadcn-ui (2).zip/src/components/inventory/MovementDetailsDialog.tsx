import React from 'react';
import { format } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StockMovement } from '@/hooks/use-stock-movements';
import { ArrowRight, Package, ArrowDownUp, Filter, ShoppingCart, ClipboardList } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface MovementDetailsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  movement: StockMovement | null;
}

const MovementDetailsDialog: React.FC<MovementDetailsDialogProps> = ({
  isOpen,
  onClose,
  movement
}) => {
  if (!movement) return null;

  const getMovementTypeIcon = (type: string) => {
    switch (type) {
      case 'New Stock':
        return <Package className="h-5 w-5 text-green-500" />;
      case 'Transfer':
        return <ArrowRight className="h-5 w-5 text-purple-500" />;
      case 'Stock Out':
        return <ArrowDownUp className="h-5 w-5 text-red-500" />;
      case 'Adjustment':
        return <Filter className="h-5 w-5 text-gray-500" />;
      default:
        return null;
    }
  };

  const getMovementBadgeStyle = (type: string) => {
    switch (type) {
      case 'New Stock':
        return 'default';
      case 'Transfer':
        return 'secondary';
      case 'Stock Out':
        return 'destructive';
      case 'Adjustment':
        return 'outline';
      default:
        return 'outline';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {getMovementTypeIcon(movement.movementType)}
            <span>Stock Movement Details</span>
            <Badge variant={getMovementBadgeStyle(movement.movementType) as "default" | "secondary" | "destructive" | "outline"} className="ml-2">
              {movement.movementType}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Detailed information about this stock movement
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Date & Time</h4>
              <p>{format(new Date(movement.date), 'MMM dd, yyyy HH:mm')}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Initiated By</h4>
              <p>{movement.initiatedBy}</p>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Product</h4>
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center mr-3">
                <Package className="h-5 w-5 text-gray-500" />
              </div>
              <div>
                <p className="font-medium">{movement.productName}</p>
                <p className="text-sm text-gray-500">Batch: {movement.batchNumber}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Quantity</h4>
              <p className="text-xl font-bold">{movement.quantity}</p>
            </div>
            
            {movement.referenceId && (
              <div>
                <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Reference</h4>
                <div className="flex items-center gap-1">
                  <ClipboardList className="h-4 w-4 text-gray-500" />
                  <p>{movement.referenceId}</p>
                </div>
              </div>
            )}
          </div>

          {movement.movementReason && (
            <div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Reason</h4>
              <p>{movement.movementReason}</p>
            </div>
          )}

          <Separator />

          <div className="grid grid-cols-2 gap-4">
            {movement.movementType !== 'New Stock' && (
              <div>
                <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">From</h4>
                {movement.fromWarehouse ? (
                  <>
                    <p className="font-medium">{movement.fromWarehouse}</p>
                    <p className="text-sm text-gray-500">{movement.fromLocation}</p>
                  </>
                ) : (
                  <p className="text-gray-500">-</p>
                )}
              </div>
            )}

            {movement.movementType !== 'Stock Out' && (
              <div>
                <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">To</h4>
                {movement.toWarehouse ? (
                  <>
                    <p className="font-medium">{movement.toWarehouse}</p>
                    <p className="text-sm text-gray-500">{movement.toLocation}</p>
                  </>
                ) : (
                  <p className="text-gray-500">-</p>
                )}
              </div>
            )}
          </div>

          {movement.orderNumber && (
            <>
              <Separator />
              
              <div>
                <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Customer Order</h4>
                <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-md">
                  <div className="flex items-center">
                    <ShoppingCart className="h-5 w-5 text-blue-500 mr-3" />
                    <div>
                      <p>Order <span className="font-medium">#{movement.orderNumber}</span></p>
                      {movement.customerName && (
                        <p className="text-sm text-gray-500">Customer: {movement.customerName}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MovementDetailsDialog;