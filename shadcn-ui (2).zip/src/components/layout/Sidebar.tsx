import { cn } from '@/lib/utils';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Archive, 
  Tags, 
  Users, 
  FileBarChart, 
  Settings, 
  ShoppingCart,
  PackageOpen,
  Truck,
  ClipboardList,
  MoveVertical
} from 'lucide-react';

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  subItems?: NavItem[];
}

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar = ({ isOpen }: SidebarProps) => {
  const location = useLocation();
  const path = location.pathname;
  
  const navItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: LayoutDashboard
    },
    {
      name: "Inventory",
      href: "/inventory",
      icon: Archive,
      subItems: [
        {
          name: "Categories",
          href: "/categories",
          icon: Tags
        }
      ]
    },

    {
      name: "Supply Management",
      href: "/supply-management",
      icon: Truck,
      subItems: [
        {
          name: "Suppliers",
          href: "/supply-management?tab=suppliers",
          icon: Truck
        },
        {
          name: "Purchase Orders",
          href: "/supply-management?tab=purchases",
          icon: ShoppingCart
        }
      ]
    },

    {
      name: "Stock Out",
      href: "/stock-out",
      icon: PackageOpen
    },
    {
      name: "Stock Movements",
      href: "/stock-movements",
      icon: MoveVertical
    },
    {
      name: "Customer Orders",
      href: "/customer-orders",
      icon: ClipboardList
    },
    {
      name: "Users",
      href: "/users",
      icon: Users
    },
    {
      name: "Reports",
      href: "/reports",
      icon: FileBarChart
    },
    {
      name: "Settings",
      href: "/settings",
      icon: Settings
    },
  ];

  return (
    <aside className={cn(
      "bg-white dark:bg-gray-950 border-r fixed left-0 top-0 h-full transition-all duration-300 ease-in-out z-20",
      isOpen ? "translate-x-0 w-64" : "-translate-x-full w-64 md:translate-x-0 md:w-20"
    )}>
      <div className="p-4 h-14 border-b flex items-center justify-center">
        <Link to="/" className="flex items-center justify-center">
          <span className={cn("font-bold text-xl", isOpen ? "block" : "hidden md:hidden")}>
            Stock Manager
          </span>
          <span className={cn("font-bold text-xl", isOpen ? "hidden" : "hidden md:block")}>
            SM
          </span>
        </Link>
      </div>
      <nav className="p-2 pt-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.name}>
              <Link 
                to={item.href} 
                className={cn(
                  "flex items-center py-2 px-3 rounded-md transition-colors hover:bg-gray-100 dark:hover:bg-gray-800",
                  (path === item.href || 
                   (item.href !== '/' && path.startsWith(item.href))) && 
                   "bg-blue-50 text-blue-700 dark:bg-gray-800 dark:text-blue-400"
                )}
              >
                <item.icon className="h-5 w-5 mr-2 shrink-0" />
                <span className={cn("text-sm font-medium", isOpen ? "block" : "hidden md:hidden")}>
                  {item.name}
                </span>
              </Link>
              {item.subItems && isOpen && (
                <ul className="ml-6 mt-2 space-y-2">
                  {item.subItems.map((subItem) => (
                    <li key={subItem.name}>
                      <Link 
                        to={subItem.href} 
                        className={cn(
                          "flex items-center py-2 px-3 rounded-md transition-colors hover:bg-gray-100 dark:hover:bg-gray-800",
                          (path === subItem.href || 
                          (subItem.href !== '/' && path.startsWith(subItem.href))) && 
                          "bg-blue-50 text-blue-700 dark:bg-gray-800 dark:text-blue-400"
                        )}
                      >
                        <subItem.icon className="h-4 w-4 mr-2 shrink-0" />
                        <span className="text-sm font-medium">{subItem.name}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;