import { X, Package, Truck, Calendar, CreditCard, User, MapPin, FileText, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';

import { Order } from '@/hooks/use-customer-orders';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface OrderDetailsDialogProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
}

// Helper function for formatting currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

// Helper function for status badges
const OrderStatusBadge = ({ status }: { status: string }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  
  switch (status.toLowerCase()) {
    case 'completed':
      variant = "default"; // Green
      break;
    case 'processing':
      variant = "secondary"; // Orange/Yellow
      break;
    case 'cancelled':
      variant = "destructive"; // Red
      break;
    case 'pending':
    default:
      variant = "outline"; // Gray outline
      break;
  }
  
  return <Badge variant={variant}>{status}</Badge>;
};

const OrderDetailsDialog = ({ order, isOpen, onClose }: OrderDetailsDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center justify-between">
            <div>
              Order #{order.orderNumber}
              <span className="ml-4">
                <OrderStatusBadge status={order.status} />
              </span>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
            <Calendar className="h-4 w-4" />
            {format(new Date(order.orderDate), 'PPP, p')}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Customer Information */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-2">
              <User className="h-4 w-4" />
              Customer Information
            </h3>
            <div className="grid sm:grid-cols-2 gap-3 text-sm">
              <div>
                <div className="font-medium">{order.customer.name}</div>
                <div className="text-gray-500 dark:text-gray-400">{order.customer.email}</div>
                <div className="text-gray-500 dark:text-gray-400">{order.customer.phone}</div>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Order Items */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-2">
              <Package className="h-4 w-4" />
              Order Items
            </h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50%]">Product</TableHead>
                  <TableHead className="text-right">Unit Price</TableHead>
                  <TableHead className="text-center">Quantity</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {order.items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.productName}</TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(item.unitPrice)}
                    </TableCell>
                    <TableCell className="text-center">{item.quantity}</TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(item.totalPrice)}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow>
                  <TableCell colSpan={3} className="text-right font-semibold">
                    Total Amount:
                  </TableCell>
                  <TableCell className="text-right font-bold">
                    {formatCurrency(order.totalAmount)}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
          
          <Separator />
          
          {/* Shipping and Billing */}
          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold flex items-center gap-2 mb-2">
                <Truck className="h-4 w-4" />
                Shipping Information
              </h3>
              <div className="text-sm space-y-1">
                <div className="font-medium">Shipping Method:</div>
                <div className="mb-2">{order.shippingMethod}</div>
                <div className="font-medium flex items-center gap-2">
                  <MapPin className="h-3 w-3" />
                  Shipping Address:
                </div>
                <div className="whitespace-pre-line">{order.shippingAddress}</div>
                
                {order.trackingNumber && (
                  <div className="mt-2">
                    <div className="font-medium">Tracking Number:</div>
                    <div className="flex items-center">
                      <span className="text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
                        {order.trackingNumber}
                      </span>
                    </div>
                  </div>
                )}
                
                {order.estimatedDelivery && (
                  <div className="mt-2">
                    <div className="font-medium">Estimated Delivery:</div>
                    <div>{format(new Date(order.estimatedDelivery), 'PPP')}</div>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold flex items-center gap-2 mb-2">
                <CreditCard className="h-4 w-4" />
                Payment Information
              </h3>
              <div className="text-sm space-y-1">
                <div className="font-medium">Payment Method:</div>
                <div className="mb-2">{order.paymentMethod}</div>
                <div className="font-medium flex items-center gap-2">
                  <MapPin className="h-3 w-3" />
                  Billing Address:
                </div>
                <div className="whitespace-pre-line">{order.billingAddress}</div>
              </div>
            </div>
          </div>
          
          {/* Notes (if any) */}
          {order.notes && (
            <>
              <Separator />
              <div>
                <h3 className="font-semibold flex items-center gap-2 mb-2">
                  <FileText className="h-4 w-4" />
                  Notes
                </h3>
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md text-sm">
                  {order.notes}
                </div>
              </div>
            </>
          )}
          
          {/* Status for cancelled orders */}
          {order.status === 'cancelled' && (
            <>
              <Separator />
              <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-md">
                <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium">Order Cancelled</div>
                  <div className="text-sm">{order.notes || 'This order has been cancelled.'}</div>
                </div>
              </div>
            </>
          )}
        </div>
        
        <div className="flex justify-end gap-2 mt-4">
          {order.status === 'completed' && (
            <Button variant="outline" onClick={() => console.log(`Downloading invoice for order ${order.id}`)}>
              Download Invoice
            </Button>
          )}
          {(order.status === 'processing' || order.status === 'completed') && (
            <Button variant="outline" onClick={() => console.log(`Tracking order ${order.id}`)}>
              Track Order
            </Button>
          )}
          <Button onClick={onClose}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailsDialog;